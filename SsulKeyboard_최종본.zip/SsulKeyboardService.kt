package com.example.ssulkeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * 쓸기자판(keyboard.html)을 실제 안드로이드 시스템 키보드(IME)로 동작시키는 서비스.
 *
 * keyboard.html 내부의 자바스크립트가
 *   window.AndroidBridge.commitText(문자)
 *   window.AndroidBridge.deleteText()
 * 를 호출하도록 이미 작성되어 있어서, 여기서는 그 두 함수를 받아
 * 실제 입력창(EditText 등)에 글자를 넣거나 지우기만 하면 됩니다.
 */
class SsulKeyboardService : InputMethodService() {

    private var webView: WebView? = null

    override fun onCreateInputView(): View {
        val heightPx = (280 * resources.displayMetrics.density).toInt()

        // WebView 하나만 반환하면 높이 계산이 0이 되는 경우가 있어
        // 크기가 확실한 FrameLayout으로 한 번 감싼다.
        val container = FrameLayout(this)
        container.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            heightPx
        )
        container.setBackgroundColor(0xFFD1D8E0.toInt())

        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true  // localStorage(클립보드/이모티콘/한자 기록용) 사용
        wv.settings.allowFileAccess = true
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.setBackgroundColor(0x00000000)

        wv.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        wv.webViewClient = WebViewClient()
        wv.loadUrl("file:///android_asset/keyboard.html")

        container.addView(wv)

        webView = wv
        return container
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        webView?.destroy()
        webView = null
    }

    /** keyboard.html의 자바스크립트에서 호출하는 다리 역할 클래스 */
    inner class AndroidBridge {

        @JavascriptInterface
        fun commitText(text: String) {
            currentInputConnection?.commitText(text, 1)
        }

        @JavascriptInterface
        fun deleteText() {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
    }
}
