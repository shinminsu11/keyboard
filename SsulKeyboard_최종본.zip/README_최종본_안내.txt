쓸기자판 최종본 파일 안내
====================================

이 zip에는 지금까지 작업한 최종 코드 5개 파일이 들어있습니다.
이미 Android Studio에 만들어두신 SsulKeyboard 프로젝트가 있다면,
아래 표에 따라 "이 파일 내용으로 덮어쓰기"만 하시면 됩니다.

┌─────────────────────────────┬──────────────────────────────────────────────────────┐
│ 이 zip 안의 파일              │ 프로젝트에서 덮어쓸 위치                                    │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ keyboard.html                │ app/src/main/assets/keyboard.html                     │
│ SsulKeyboardService.kt       │ app/src/main/java/com/example/ssulkeyboard/           │
│                               │   SsulKeyboardService.kt                              │
│ AndroidManifest.xml          │ app/src/main/AndroidManifest.xml                      │
│ method.xml                   │ app/src/main/res/xml/method.xml                       │
│ strings.xml                  │ app/src/main/res/values/strings.xml                   │
└─────────────────────────────┴──────────────────────────────────────────────────────┘

[SsulKeyboardService.kt에서 마지막에 바뀐 부분]
- WebView를 그냥 반환하지 않고 FrameLayout으로 감싸서 반환하도록 변경
- 키보드 영역 높이를 280dp로 고정 지정 (기존엔 WRAP_CONTENT라 0으로 계산되는
  문제가 있었음 — 이게 "자판이 화면에 안 뜨던" 문제의 유력한 원인이었습니다)
- onEvaluateFullscreenMode()를 false로 오버라이드 추가

[아직 확인 안 된 것]
이 변경사항을 실제 프로젝트 파일에 넣고 재빌드 후 테스트하는 것까지는
진행하지 못했습니다. 다음에 다시 시도하실 때는:
1. 이 zip의 SsulKeyboardService.kt 내용을 프로젝트에 덮어쓰기
2. Build → Build APK(s)
3. 폰에 재설치 (기존 앱 삭제 후 설치 권장)
4. 그래도 안 뜨면 Logcat에서 "ssulkeyboard" 필터로 로그 확인

[HTML 자판 코드 자체]
keyboard.html은 그동안 요청하신 대로 이미 다 수정된 상태입니다
(Shift/삭제 버튼 크기, 홈 아이콘 크기 등).
