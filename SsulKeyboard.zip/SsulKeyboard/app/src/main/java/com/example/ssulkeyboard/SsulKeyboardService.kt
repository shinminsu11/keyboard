package com.example.ssulkeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * 쓸기자판(keyboard.html)을 실제 안드로이드 시스템 키보드(IME)로 동작시키는 서비스.
 *
 * keyboard.html 내부의 자바스크립트가
 *   window.AndroidBridge.commitText(문자)
 *   window.AndroidBridge.deleteText()
 * 를 호출하도록 이미 작성되어 있어서, 여기서는 그 두 함수를 받아
 * 실제 입력창(EditText 등)에 글자를 넣거나 지우기만 하면 됩니다.
 */
class SsulKeyboardService : InputMethodService() {

    private var webView: WebView? = null

    override fun onCreateInputView(): View {
        val wv = WebView(this)
        wv.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true  // localStorage(클립보드/이모티콘/한자 기록용) 사용
        wv.settings.allowFileAccess = true
        wv.settings.useWideViewPort = false
        wv.settings.loadWithOverviewMode = false
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.overScrollMode = View.OVER_SCROLL_NEVER

        wv.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        wv.webViewClient = WebViewClient()
        wv.loadUrl("file:///android_asset/keyboard.html")

        webView = wv
        return wv
    }

    override fun onDestroy() {
        super.onDestroy()
        webView?.destroy()
        webView = null
    }

    /** keyboard.html의 자바스크립트에서 호출하는 다리 역할 클래스 */
    inner class AndroidBridge {

        @JavascriptInterface
        fun commitText(text: String) {
            currentInputConnection?.commitText(text, 1)
        }

        @JavascriptInterface
        fun deleteText() {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
    }
}
