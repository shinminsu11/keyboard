쓸기자판 (com.example.ssulkeyboard) - Android Studio 프로젝트
================================================================

이 프로젝트는 만드신 keyboard.html(쓸기자판)을 실제 안드로이드
시스템 키보드로 동작하게 감싸는 최소 구조입니다.

[구조]
- app/src/main/assets/keyboard.html
  → 만드신 자판 코드 그대로 들어있습니다. 자판 디자인/기능을 고치고
    싶으면 이 파일만 수정하면 됩니다.

- app/src/main/java/com/example/ssulkeyboard/SsulKeyboardService.kt
  → 시스템 키보드 서비스. WebView로 keyboard.html을 띄우고,
    keyboard.html이 호출하는 AndroidBridge.commitText() /
    AndroidBridge.deleteText()를 받아서 실제 메모장 등 다른 앱의
    입력창에 글자를 써주고 지워줍니다.

- app/src/main/res/xml/method.xml, AndroidManifest.xml
  → 안드로이드에 "이 앱은 키보드(IME)다"라고 등록하는 설정 파일.


[빌드 방법 - Android Studio 사용]
1. Android Studio 설치 (무료, https://developer.android.com/studio)
2. Android Studio 실행 → "Open" → 이 SsulKeyboard 폴더 통째로 열기
3. 처음 열면 Gradle 동기화가 자동으로 진행됩니다 (인터넷 필요, 시간 걸림)
4. 상단 메뉴 Build → Build Bundle(s) / APK(s) → Build APK(s)
5. 빌드가 끝나면 알림에 뜨는 "locate" 링크를 누르면
   app/build/outputs/apk/debug/app-debug.apk 파일이 나옵니다.
6. 이 apk 파일을 휴대폰에 설치하면 됩니다.
   (설치 전 휴대폰 설정에서 "출처를 알 수 없는 앱 설치 허용" 필요)


[휴대폰에서 키보드 활성화 방법]
1. 앱 설치 후 휴대폰 설정 → 일반 → 키보드 (또는 "시스템" → "언어 및 입력")
   → "화면 키보드" 또는 "가상 키보드 관리"로 들어갑니다.
2. "쓸기자판"을 켜기(활성화) 해줍니다.
3. 메모장 등 아무 텍스트 입력창을 누른 뒤,
   화면 하단 키보드 아이콘(키보드 전환 버튼)을 눌러 "쓸기자판"으로
   전환하면 실제로 만드신 디자인의 자판이 뜹니다.


[참고 - 온라인 빌드 서비스를 쓰고 싶다면]
Android Studio 설치가 어려우면, 이 폴더를 통째로 GitHub 저장소에
올린 뒤 GitHub Actions(무료 CI)나 온라인 안드로이드 빌드 서비스에
연결해서 APK를 뽑는 방법도 있습니다. 그 경우 저장소 주소를
알려주시면 GitHub Actions 빌드 설정 파일(.yml)도 만들어드릴 수
있습니다.
